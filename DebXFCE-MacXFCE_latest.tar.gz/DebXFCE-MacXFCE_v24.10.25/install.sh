#!/bin/bash
#
# This script will gather some things from the internet.
#
# Enjoy!
# -Joseph
#
# olddognewlinux@gmail.com
#
#
# Checking for an internet connection...
#
ping -c2 google.com >/dev/null

	if [ $? -eq 0 ]; then
  clear 
echo 
echo "   Good! You have the necessary internet connection for installation."
echo 
echo "   This could take a while depending on the speed of your internet connection and computer resource."
echo 
read -p "   Press Enter to continue with the installation, or Ctrl-Z to abort..."
echo
echo
echo
echo "   Please input password to continue..."
echo
echo
#
# Retrieving a few applications to make things nice...
#
# Adding Albert repository...
#
echo 'deb http://download.opensuse.org/repositories/home:/manuelschneid3r/Debian_12/ /' | sudo tee /etc/apt/sources.list.d/home:manuelschneid3r.list
curl -fsSL https://download.opensuse.org/repositories/home:manuelschneid3r/Debian_12/Release.key | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/home_manuelschneid3r.gpg > /dev/null
#
# Adding Fsearch repository...
#
echo 'deb http://download.opensuse.org/repositories/home:/cboxdoerfer/Debian_12/ /' | sudo tee /etc/apt/sources.list.d/home:cboxdoerfer.list
curl -fsSL https://download.opensuse.org/repositories/home:cboxdoerfer/Debian_12/Release.key | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/home_cboxdoerfer.gpg > /dev/null
#
# Adding Google Chrome repository...
#
echo deb [arch=amd64 signed-by=/usr/share/keyrings/google-chrome.gpg] http://dl.google.com/linux/chrome/deb/ stable main | sudo tee /etc/apt/sources.list.d/google-chrome.list
curl -fSsL https://dl.google.com/linux/linux_signing_key.pub | sudo gpg --dearmor | sudo tee /usr/share/keyrings/google-chrome.gpg >> /dev/null
#
# Adding Brave Browser repository...
#
echo "deb [signed-by=/usr/share/keyrings/brave-browser-archive-keyring.gpg] https://brave-browser-apt-release.s3.brave.com/ stable main"|sudo tee /etc/apt/sources.list.d/brave-browser-release.list
sudo curl -fsSLo /usr/share/keyrings/brave-browser-archive-keyring.gpg https://brave-browser-apt-release.s3.brave.com/brave-browser-archive-keyring.gpg
#
sudo apt update
#
# Install applications... (some apps may already exist-- those will be ignored)
#
for app in xfce4-goodies xfce4-appmenu* vala-panel-appmenu* xfce4-panel-profiles gnome-disk-utility gnome-system-tools plank gparted gdebi hardinfo grub-customizer nemo baobab gnome-system-monitor gnome-software flatpak gnome-software-plugin-flatpak transmission-gtk galculator mugshot wget htop numlockx wavemon gigolo libcanberra-gtk-module libcanberra-gtk3-module albert fsearch google-chrome-stable brave-browser lazpaint-gtk2; do sudo apt install -y $app; done
#
wget https://dl.flathub.org/repo/flathub.flatpakrepo
sudo flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo
#
echo
echo "								       ***** ALMOST THERE! *****"
echo
sleep 3
#
# Copying modified configuration files to where they belong...
#
sudo chmod -R ugo+rw *
sudo chmod ugo+x decor.sh
sudo cp files/*.desktop /usr/share/applications
sudo cp files/autologin-toggle.sh /usr/bin
sudo cp files/slick-greeter.conf /etc/lightdm
sudo cp files/defaults.list /usr/share/xfce4/applications
sudo cp files/52libcanberra-gtk-module_add-to-gtk-modules /etc/X11/Xsession.d
sudo cp files/52appmenu-gtk-module_add-to-gtk-modules /etc/X11/Xsession.d
sudo cp /usr/share/applications/defaults.list /usr/share/applications/defaults.list.BAK
sudo sed -i 's/xed/org.xfce.mousepad/g' /usr/share/applications/defaults.list
sudo cp /usr/share/applications/xfce4-file-manager.desktop /usr/share/applications/xfce4-file-manager.desktop.BAK
sudo sed -i 's/exo-open --launch FileManager %u/nemo %u/' /usr/share/applications/xfce4-file-manager.desktop
sudo cp /etc/xdg/xfce4/helpers.rc /etc/xdg/xfce4/helpers.rc.BAK
sudo cp .config/xfce4/helpers.rc /etc/xdg/xfce4/helpers.rc
sudo chmod ugo+rw /usr/share/applications/*.desktop
sudo chmod ugo+rwx /usr/bin/*.sh
#
# Run the second script...
#
source decor.sh
#
exit
#
	else
 clear
echo
echo "   ********************************************************"
echo "      YOU MUST CONNECT TO THE INTERNET BEFORE CONTINUING."
echo "   ********************************************************"
echo

	fi

while true; do
    read -p "   Are you ready to connect now? y/n " yn
echo
    case $yn in
	[Yy]* ) nmtui 2> /dev/null; clear; echo; source install.sh; exit;;
        [Nn]* ) clear; echo; echo "   Okay. We'll try this again when you're ready."; echo; exit;;
        * ) 
    esac
done
#
