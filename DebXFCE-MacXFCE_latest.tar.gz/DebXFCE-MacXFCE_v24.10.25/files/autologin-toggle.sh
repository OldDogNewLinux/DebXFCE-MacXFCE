#!/bin/bash
# My second attempt at bash scripting.
#
# AutoLogin-Toggle
# Created: 2024-09-13
#
# A lot of people including myself are looking for a simple solution for enabling or disabling autologin for Linux,
# particularly for the XFCE desktop environment using the LightDM login interface.
# Necessity is the mother of invention. So here it is. 
#
# This script will add an application to the System Manager that allows you to Enable and Disable Automatic Login on an XFCE desktop using the LightDM login manager.
#
# Version System:  YY.MM.DD (2-DIGIT YEAR.MONTH.DAY)
#
# Enjoy! 
# -Joseph
#
# olddognewlinux@gmail.com
#
while true; do
clear
echo
echo "   ***************************************************************"
echo "    This script will ENABLE or DISABLE autologin for user $USER."
echo "   ***************************************************************"
echo
    read -p "   Do you want to Enable or Disable autologin? e/d " ed
echo
    case $ed in
        [Ee]* ) sudo sed -i 's/.*autologin-user=.*/autologin-user='$USER'/' /etc/lightdm/lightdm.conf ; 
echo; echo "   Autologin is now ENABLED."; echo; sleep 3; exit;;
        [Dd]* ) sudo sed -i 's/autologin-user=.*/#autologin-user=/' /etc/lightdm/lightdm.conf ; 
echo; echo "   Autologin is now DISABLED."; echo; sleep 3; exit;;
        * ) 
    esac
done
#
